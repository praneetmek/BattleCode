package firstiteration;

public final class PersonalConstants {
    private PersonalConstants(){}
    public static final int INDEX_OF_ARCHON = 20;
    public static final int INDEX_OF_DANGER = 21;
    public static final int INDEX_OF_FRONT_LINE = 22;
    public static final int INDEX_OF_ARCHON_LOCS = 23;
}
