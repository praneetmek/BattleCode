package firstiteration;

public final class PersonalConstants {
    private PersonalConstants(){}
    public static final int INDEX_OF_ARCHON = 20;
}
