Shared Array:
Index 0: Location of Archon